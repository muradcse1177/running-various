<!DOCTYPE html PUBLIC >
<html lang="en">
<head>
<title>Main Page</title>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="pom.css"  />
</head>

<body>
<div id="wrap">
  <div id="header"><br />
    <h3><font size="6">Address_Book</font></h3>
    <p><strong>"Useful,Helpful,Essential"</strong></p>
  </div>
  <img  src="images/we.jpg" width="790" height="228" alt="" />
  <div id="avmenu">
    <h2 class="hide">Menu:</h2>
    <ul>
      <li><a href="index.php">Back to Main Page</a></li>
      <li><a href="add_map.php">Address_Book map</a></li>
      <li><a href="">Important Addresses</a></li>
      <li><a href="login.php"><font color="blue">LOGIN Page</font></a></li>
    </ul>
    
  </div>
  
<div id="extras">
    <h3>&nbsp;<br />
      </h3>
   
    

    <p class="small">Design<br />
      (10 February, 2014)<br />
      <a href="http://validator.w3.org/check/referer">Validate XHTML 1.0 Strict</a><br />
      and Css </p>
  </div>
  <div id="content"> &nbsp;
    <h2><img src="images/ill_title.jpg" alt="ill title" width="63" height="20" />About It ! </h2><br>
    <p><img src="images/ques1.jpg" height="100" width="125" class="left" alt="ill_1" />
      <font size="3">
        <ol type="1">
          <li>1. Simple, web-based address & phone book</li>
          <li>2. Manages contacts & groups</li>
          <li>3. Protects the site with a login</li>
          <li>4. Displays the next birthdays of your friend</li>
          <li>Show geographical maps of friends</li>
        </ol>
      </font>
    </p>
  </div>
  <div id="footer"> Copyright &copy; 2014. Design by Moyeen Shuvo.</div>
</div>
</body>
</html>

<?php require_once("includes/connection.php"); ?>
<div id="templatemo_footer_wrapper">
    <div id="templatemo_footer">
        Copyright � 2012 <a href="#">Code Breakers</a> | Designed by STA | <a href="http://www.facebook.com/tauhid.kuet" target="_blank">fb</a>
    </div> 
</div>
<?php
	mysql_close($connection);
?>
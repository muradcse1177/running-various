<div id="templatemo_header_wrapper">
	<div id="templatemo_header">

            	<div id="site_title"><h1>Live Your Dream</h1></div>

        <div id="templatemo_menu" class="ddsmoothmenu">
            <ul>
                <li><a href="index.php" class="selected">Home</a></li>
                
                <li><a href="gallery.php">Gallery</a>
                    
                </li>
                <li><a href="blog.php">Blog</a></li>
                <li><a href="contact.php">Contact</a></li>
                <li><a href="">Account</a>
                    <ul>
                        <li><a href="account.php">View</a></li>
                        <li><a href="logout.php">logout</a></li>
                    </ul>
                </li>
            </ul>
            <br style="clear: left" />
           
        </div> <!-- end of templatemo_menu -->
    </div> <!-- END of templatemo_header -->
</div>
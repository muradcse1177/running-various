<?php session_start(); ?>

<!DOCTYPE html PUBLIC >
<html lang="en">
<head>
<title>Main Page</title>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="pom.css"  />

<style type="text/css">
  #smiddle{
width:187px;
height:33px;
padding-top:5px;
background-image:url(images/searchbg.jpg);
background-repeat:repeat-x;
float:left;
margin:auto;
}

#search{
width:49px;
height:auto;
float:left;
margin:auto;
padding-top:3px;
font-family:Arial, Helvetica, sans-serif;
font-size:20px;
text-align:center;
color:white; background-color:inherit;
}

#sbox{
width:105px;
height:auto;
float:left;
margin:auto;
}

#sbutton{
width:30px;
height:auto;
padding-top:3px;
text-align:center;
float:left;
margin:auto;
}
</style>
</head>

<body>
<div id="wrap">
  <div id="header"><br />
    <h3><font size="6">Address_Book</font></h3>
    <p><strong>"Useful,Helpful,Essential"</strong></p>
  </div>
<hr/>
<div>&nbsp;</div>
<center><html><font color="#95FF4F" size="6"><?php echo 'Welcome to '.$_SESSION['username']; ?></font></html></center><br>

  <div id="avmenu">
    <h2 class="hide">Menu:</h2>
    <ul>
      <li><a href="">Friend Request</a></li>
      <li><a href="">View Profile</a></li>
    </ul>  
  </div>
  <br>

  <div id="smiddle">
          <div id="search">Search:</div>
          <div id="sbox">
            <form id="form1" name="form1" method="post" action="http://www.free-css.com/">
              <input type="text" name="textfield"  style="width:100px; height:15px; border:1px solid #B2B2B1;" />
            </form>
          </div>
          <div id="sbutton">
            <label>
            <input type="image" name="imageField" src="images/searchbutton.jpg" title="Go" />
            </label>
          </div>
  </div>




 <div id="footer"> Copyright &copy; 2014. Design by Moyeen Shuvo.</div>
</div>
</body>
</html>
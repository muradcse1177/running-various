<!DOCTYPE HTML PUBLIC >
<html>
<head>
  <title>Registration Page</title>

  <META name="Author" Content="Bit Repository">
 <META name="Keywords" Content="form, divs">
  <META name="Description" Content="A CSS Tableless Form Design">
 
<style TYPE="text/css">
<!--
HTML, BODY
{
padding: 0;border: 0px none;
}
 
/* Stylish FieldSet */
fieldset
{
-moz-border-radius: 7px; border: 1px #dddddd solid; padding: 10px; width: 330px; margin-top: 10px;
}
 
fieldset legend
{
border: 1px #1a6f93 solid; color: black; font: 13px Verdana; padding: 2 5 2 5; -moz-border-radius: 3px;
}
 
/* Label */
label
{
width: 100px; padding-left: 20px; margin: 5px; float: left; text-align: left;
}
 
/* Input text */
input { margin: 5px; padding: 0px; float: left; }
 /* 'Login' Button */
#submit { margin: 5px; padding: 0px; float: left; width: 50px; background-color: white; }
 
#error_notification
{
border: 1px #A25965 solid;
height: auto;
padding: 4px;
background: #F8F0F1;
text-align: center;
-moz-border-radius: 5px;
}

.error{
      color: #FF0000;
    }
 
/* BR */
 
br { clear: left; }
-->
</style>

<link rel="stylesheet" type="text/css" href="pom.css"  />
 
</head>

 <body>

 <div id="wrap">
 <div id="header"><br />
    <h3><font size="6">Address_Book</font></h3>
    <p><strong>"Useful,Helpful,Essential"</strong></p>
  </div>

  <hr/>
 
  <div id="avmenu">
    <h2 class="hide">Menu:</h2>
    <ul>
      <li><a href="login.php">Back to Login Page</a></li>
    </ul>   
  </div>

<?php require_once("includes/connection.php"); ?>
<?php require_once("includes/session.php"); ?>

<?php

       //error_reporting(0);
 $nameErr = $emailErr = $genderErr = $countryErr = $ageErr = $pass= $passErr = $pass1= $passErr1= $birth=$birthErr="";
 $username= $password = $password1 = $email = $gender = $country = $age = $education = $proErr=$pro ="";
 $full=$fullErr=$phone=$phoneErr="";
 $flag = 'ok';  
      //if(isset($_POST['login'])) {
        if ($_SERVER["REQUEST_METHOD"] == "POST")
        { 
    //uername... 
          if (empty($_POST["username"]))
           {
              $nameErr = " *UserName is required";
              $flag ='not';
           }
           else
           {
            $username = test_input($_POST['username']);
            // check if name only contains letters and whitespace
              if (!preg_match("/^[a-zA-Z ]*$/",$username))
              {
                $nameErr = "* Only letters and white space allowed";
                $username="";
                $flag ='not';
              }
           }
    //FullName
           if (empty($_POST["full"]))
           {
              $fullErr = " *Full Name is required";
              $flag ='not';
           }
           else
           {
            $full = test_input($_POST['full']);
            // check if name only contains letters and whitespace
              if (!preg_match("/^[a-zA-Z ]*$/",$full))
              {
                $fullErr = "* Only letters and white space allowed";
                $full="";
                $flag ='not';
              }
           }
    //Email...
           if (empty($_POST["email"]))
            {
            	$emailErr = "* Email is required";
            	$flag ='not';
            }
           else if (!empty($_POST['email']) && isset($_POST['submit'])) 
           {
    	        $email=$_POST['email'];
              /*if(filter_var($email, FILTER_VALIDATE_EMAIL))	
               {
              //$emailErr = "Email is permitted";
                $email_address= test_input($_POST["email"]);
               }
               else{$emailErr="Please write valid Email address";}*/
            }

    //Password
            if (empty($_POST["password"]))
            {
              $passErr = " * Password is required";
              $flag ='not';
            }
            else
            {
              $password = $_POST['password'];
              $pass=md5($password);
              //echo "$pass";
            }
    //Verify Password
            if (empty($_POST["re_password"]))
            {
              $passErr1 = " * Verify Password is required";
              $flag ='not';
            }
            else
            {
              $password1 = $_POST['re_password'];
              $pass1=md5($password1);

              if($pass!=$pass1)
              {
                $passErr1 = " * Verify Password does not match";
                $flag='not';
              }
            }
    //Age
        if (empty($_POST["age"]))
          {
          	$ageErr = "* Age is required";
          	$flag ='not';
          }
        else if(!empty($_POST['age']) && isset($_POST['submit'])) 
        {
  	        if(is_numeric($_POST['age']))
            {
              $age= test_input($_POST["age"]);
            }
            else{$ageErr = "* Age must be number_format"; $flag ='not';}
        }
    //Gender
        if (empty($_POST["sex"]))
          {
          	$genderErr = "* Gender is required";
          	$flag ='not';
          }
        else
          {
          	$gender = test_input($_POST["sex"]);
          }
    //Profession
        if(empty($_POST['profession'])||$_POST['profession']=='select_profession')
          {
    	$flag = 'not';
    	$proErr = "* Please select education";
          }
         else
         {
         	$pro= test_input($_POST["profession"]);
         }
    //BirthDay
         if (empty($_POST["birth"]))
          {
            $birthErr = "* Birth Date is required";
            $flag ='not';
          }
        else if(!empty($_POST['birth']) && isset($_POST['submit'])) 
        {
            /*if(is_numeric($_POST['age']))
            {
              $age= test_input($_POST["age"]);
            }
            else{$ageErr = "* Age must be number_format"; $flag ='not';}*/
            $birth = test_input($_POST["birth"]);
        }
    //Phone_Number
        if(empty($_POST["phone"]))
          {
            $phoneErr = "* Phone Number is required";
            $flag ='not';
          }
        else
          {
            $phone = test_input($_POST["phone"]);
          }     
    //Country_Name
        if (empty($_POST["country"]))
          {
          	$countryErr = "* Country name is required";
          	$flag ='not';
          }
        else
          {
          	$country = test_input($_POST["country"]);
          }
    
    if ( $username!="" && $email!="" && $password!="" && $password1!="" && $age!="" && $gender!="" && $pro!="" && $country!="" 
      && $full!="" && $birth!="" && $phone!="") {
 
      // Check database to see if username and the hashed password exist there.
     // $query=mysql_query("Insert INTO login VALUES('$username','$email','$pass','$age','$gender',
      	//'$pro','$country');");

      	$query=mysql_query("SELECT * FROM login WHERE userName='$username'");
      	$checkuser=mysql_num_rows($query);

      	$query1=mysql_query("SELECT * FROM login WHERE email='$email'");
      	$checkuser1=mysql_num_rows($query1);


          if($checkuser != 0)
          {
             $nameErr="Sorry, you cannot use this name.";
             $flag='not';
          }
          else
          {
          	if ($checkuser1 != 0) 
          	{
          	  $emailErr="Sorry,This Email is already used.";
              $flag='not';
          	}
          	else
          	{
              mysql_query("Insert INTO login VALUES('$username','$full','$email','$pass','$age','$gender',
      	      '$pro','$birth','$phone','$country');");
          	}
          }

    }
  } 

  function test_input($data)
   {
     $data = trim($data);
     //trim() function removes whitespace and other predefined characters from both sides of a string.
     $data = stripslashes($data);
     //stripslashes() function removes backslashes '\'
     $data = htmlspecialchars($data);
     // htmlspecialchars() function converts some predefined characters to HTML entities.
     return $data;
   }
     
 ?>

 <?php
    if($flag=='not'||$_SERVER['REQUEST_METHOD']=='GET')
    {
      //echo "<h1>Please Leave a Comment</h1>";
    ?>
 
<center>
 
<div align="left" style="width: 330px;">
<form name="login"  action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST" >
 
<fieldset><legend><font color="#A6DEEE" size="5">Registration_Here</font></legend><br>

<label><font color="#95FF4F" size="3">Username</font></label><input id="name" type="text" name="username" 
placeholder="Enter Username" value="<?php echo $username ?>"><br />
<label>&nbsp;</label><span class='error'> <?php echo $nameErr."<br/>" ?></span>

<label><font color="#95FF4F" size="3">Full Name</font></label><input  type="text" name="full" 
placeholder="Enter Full name" value="<?php echo $full ?>"><br />
<label>&nbsp;</label><span class='error'> <?php echo $fullErr."<br/>" ?></span>

<label><font color="#95FF4F" size="3">Email</font></label><input id="name" type="email" name="email" 
placeholder="Enter Email" value="<?php echo $email ?>"><br />
<label>&nbsp;</label><span class='error'> <?php echo $emailErr."<br/>" ?></span>
 
<label><font color="#95FF4F" size="3">Password</font></label><input type="password" name="password" placeholder="Enter Password"><br />
<label>&nbsp;</label><span class='error'> <?php echo $passErr."<br/>" ?></span>

<label><font color="#95FF4F" size="3">Verify Password</font></label><input type="password" name="re_password" placeholder="Confirm Username"><br>
<label>&nbsp;</label><span class='error'> <?php echo $passErr1   ."<br/>" ?></span>

<label><font color="#95FF4F" size="3"> Age: </font></label>
			     	<input type="text" name="age" placeholder="Enter Age" value="<?php echo $age; ?>"><br/>
		<label>&nbsp;</label><span class='error'><?php echo $ageErr."<br/>"?></span>

<label><font color="#95FF4F" size="3">Gender: </font></label> 
			   		 <input type='radio' name="sex" value="Male" >Male<br/>
			   		 <label>&nbsp;</label>
			         <input type='radio' name="sex" value="Female">Female<br/>
		<label>&nbsp;</label><span class='error'><?php echo $genderErr."<br/>"?></span>

<label><font color="#95FF4F" size="3">Profession: </font></label> 
				<select name="profession"><br/>
					<option value="select_profession">Select Profession</option>
					<option value="Student">Student</option>
					<option value="Businessman">Businessman</option>
					<option value="Service Holder">Service Holder</option>
					<option value="Others">OHTERS</option>
				</select>
				<br/>
			<label>&nbsp;</label><span class='error'><?php echo $proErr."<br/>"?></span><br/>

<label><font color="#95FF4F" size="3">BirthDay</font></label><input type="date" name="birth" value="<?php echo $birth?>"/><br>
<label>&nbsp;</label><span class='error'> <?php echo $birthErr."<br/>" ?></span>

<label><font color="#95FF4F" size="3">Phone Number</font></label><input type="text" name="phone" placeholder="Enter Phone Number" value="<?php echo $phone?>"/><br>
<label>&nbsp;</label><span class='error'> <?php echo $phoneErr."<br/>" ?></span>

<label><font color="#95FF4F" size="3">Country</font></label><input type="text" name="country" 
placeholder="Enter Country Name" value="<?php echo $country?>"><br>
<label>&nbsp;</label><span class='error'> <?php echo $countryErr."<br/>" ?></span>

<label>&nbsp;</label><input id="submit" type="submit" name="submit" value="Submit"><br /><br />
 
</fieldset>
 
</form>
</div>
 
</center>

<?php
}
  
  else
  {
  	echo "You are successfully registered!!!";
  }

?>

 <div id="footer"> Copyright &copy; 2014. Design by Moyeen Shuvo.</div>
 </div>
 </body>
</html>



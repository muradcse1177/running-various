


<!DOCTYPE HTML PUBLIC >
<html>
<head>
  <title>Login Page</title>

  <META name="Author" Content="Bit Repository">
 <META name="Keywords" Content="form, divs">
  <META name="Description" Content="A CSS Tableless Form Design">
 
<style TYPE="text/css">
<!--
HTML, BODY
{
padding: 0;border: 0px none;
}
 
/* Stylish FieldSet */
fieldset
{
-moz-border-radius: 7px; border: 1px #dddddd solid; padding: 10px; width: 330px; margin-top: 10px;
}
 
fieldset legend
{
border: 1px #1a6f93 solid; color: black; font: 13px Verdana; padding: 2 5 2 5; -moz-border-radius: 3px;
}
 
/* Label */
label
{
width: 100px; padding-left: 20px; margin: 5px; float: left; text-align: left;
}
 
/* Input text */
input { margin: 5px; padding: 0px; float: left; }
 /* 'Login' Button */
#submit { margin: 5px; padding: 0px; float: left; width: 50px; background-color: white; }
 
#error_notification
{
border: 1px #A25965 solid;
height: auto;
padding: 4px;
background: #F8F0F1;
text-align: center;
-moz-border-radius: 5px;
}

.error{
      color: #FF0000;
    }
 
/* BR */
 
br { clear: left; }
-->
</style>

<link rel="stylesheet" type="text/css" href="pom.css"  />
 
</head>

 <body>

 <div id="wrap">
 <div id="header"><br />
    <h3><font size="6">Address_Book</font></h3>
    <p><strong>"Useful,Helpful,Essential"</strong></p>
  </div>
  <img  src="images/login.jpg" width="790" height="228" alt="" /><br>
  <div id="avmenu">
    <h2 class="hide">Menu:</h2>
    <ul>
      <li><a href="index.php">Main Page</a></li>
       <li><a href="add_map.php">Address_Book map</a></li>
      <li><a href="">Important Addresses</a></li>
      <li><a href="about.php">About it</a></li>
    </ul>   
  </div>

<?php require_once("includes/connection.php"); ?>
<?php require_once("includes/session.php"); ?>

<?php

       //error_reporting(0);
       $nameErr = $emailErr = $genderErr = $commentErr = $ageErr = $username= $password=  $pass= $passErr= "";
       $flag = 'ok';  
      //if(isset($_POST['login'])) {
        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {

   
       if (empty($_POST["username"]))
           {
              $nameErr = " * Name is required";
            $flag ='not';
         }
           else
           {
            $username = $_POST['username'];
           }

    
       if (empty($_POST["password"]))
           {
              $passErr = " * Password is required";
              $flag ='not';
           }
           else
           {
            $password = $_POST['password'];
            $pass=md5($password);
            //echo "$pass";
           }

     // $cook=$_POST['remember'];

       //if (isset($_POST["remember"]))
           //{
           
            //$cook = "yes";
           //}
    
    if ( $username!="" && $password!="" ) {
  //  if(isset($_POST['username']) && isset($_POST['password'])) {
      // Check database to see if username and the hashed password exist there.
      $query = "SELECT /*id,*/ userName ";
      $query .= "FROM login ";
      $query .= "WHERE userName = '{$username}' ";
      $query .= "AND userPassword = '{$pass}' ";
      $result_set = mysql_query($query);
      if (mysql_num_rows($result_set) == 1) {
        $found_user = mysql_fetch_array($result_set);
        //$_SESSION['user_id'] = $found_user['id'];
        //$_SESSION['user_name'] = $username;
        //$_SESSION['username'] = $found_user[$username];
         $_SESSION['username'] = $found_user['userName'];
        
        //if($cook=="yes")
        if(isset($_POST["remember"]))
        {
        setcookie("username", "{$username}", time()+3600);
        setcookie("password", "{$password}", time()+3600);        }
         else
         {
          setcookie("username", "", time()-3600);
          setcookie("password", "", time()-3600);
          //echo "bad";
          
         }
        header("Location: direction.php");
      } 
      else {
        // username/password combo was not found in the database
        $passErr=" * Wrong username or Password";
        $username="";
        $flag ='not';
        session_destroy();
       // header("Location: login.php");
      }
    }
  } 
     
 ?>

 <?php
    if($flag=='not'||$_SERVER['REQUEST_METHOD']=='GET')
    {
      //echo "<h1>Please Leave a Comment</h1>";
    ?>
 
<center>
 
<div align="left" style="width: 330px;">
<form name="login"  action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST" >
 
<fieldset><legend><font color="#A6DEEE" size="5">Login_Here</font></legend><br>
 
 
<label><font color="#95FF4F" size="3">Username</font></label><input id="name" type="text" name="username" 
placeholder="Enter Username" value="<?php echo $username ?>" required /><br />
<label>&nbsp;</label><span class='error'> <?php echo $nameErr."<br/>" ?></span>
 
<label><font color="#95FF4F" size="3">Password</font></label><input type="password" placeholder="Enter Password" name="password" required /><br />
<label>&nbsp;</label><span class='error'> <?php echo $passErr."<br/>" ?></span><br>

 
<label>&nbsp;</label><input type="checkbox" name="autologin" value="1"><font color="#FF7373">Remember Me
</font><br /><br />
 
<label>&nbsp;</label><input id="submit" type="submit" name="submit" value="Login"><br /><br />

<label>&nbsp;</label><p>Yet not an account???</p>
<label>&nbsp;</label><p><a href="resistration.php">Create New Account</a></p>
 
</fieldset>
 
</form>
</div>
 
</center>

<?php
}

?>

 <div id="footer"> Copyright &copy; 2014. Design by Moyeen Shuvo.</div>
 </div>
 </body>
</html>



<?php
    
    session_start();

    if($_SESSION['username'])
    {
    	header('Location: home.php');
    }

    else
    {
    	header('Location: login.php');
    }


?>
<!DOCTYPE html>
<html>

<head>
	<title>
		Address_Book Map
	</title>

   <link rel="stylesheet" type="text/css" href="pom.css"  />	
</head>

<body>
<div id="wrap">
  <div id="header"><br />
    <h3><font size="6">Address_Book MAP</font></h3>
    <p><strong>"Useful,Helpful,Essential"</strong></p>
  </div>

   <br><br>

    <div id="avmenu">
    <h2 class="hide">Menu:</h2>
    <ul>
      <li><a href="add_map.php">Address_Book map</a></li>
      <li><a href="">Important Addresses</a></li>
      <li><a href="about.php">About it</a></li>
      <li><a href="login.php"><font color="blue">LOGIN Page</font></a></li>
    </ul>
    
  </div>
    
 
 <div> &nbsp;
 <center>
 	<img src="map.png" width="600" height="500">
 </center>
 </div>

 <br><br>

  <div id="footer"> Copyright &copy; 2014. Design by Moyeen Shuvo.</div>
</div>
</body>
</html>
